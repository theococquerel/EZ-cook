<?php
session_start();
require_once __DIR__ . DIRECTORY_SEPARATOR . "Template.php";
if (!empty($_POST)and isset($_POST['login']) and isset($_POST['password'])){
    if ($_POST['login']=="admin2026" and $_POST['password']=="projet3"){
        $_SESSION['login']=$_POST['login'];
        header("Location:index.php");
        exit();

    }
    else if ($_POST['login']==""){
        $_SESSION['error']="Identifiant non rempli";
        header("Location:index.php");
        exit();
    }
    else if ($_POST['password']==""){
        $_SESSION['error']="Mot de passe non rempli";
        header("Location:index.php");
        exit();
    }
    else{
        $_SESSION['error']="Identififiant ou mot de passe incorrect";
        header("Location:index.php");
        exit();
    }
} 