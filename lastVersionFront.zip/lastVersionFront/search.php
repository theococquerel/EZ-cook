<?php
require_once "DataBase.php";

header('Content-Type: application/json');

$pdo = DataBase::getConnection();

$q = $_GET['q'] ?? '';
$tags = $_GET['tags'] ?? '';
$tags = array_filter(explode(',', $tags));

// encodage MySQL
$pdo->exec("SET NAMES utf8mb4");

// REQUÊTE SQL
$sql = "SELECT * FROM Recette WHERE 1";
$params = [];

// filtre texte (accent + casse INSENSIBLE)
if ($q !== '') {
    $sql .= " AND (
        titre COLLATE utf8mb4_general_ci LIKE :q
        OR description COLLATE utf8mb4_general_ci LIKE :q
    )";
    $params[':q'] = "%" . $q . "%";
}

// 🔍 filtre tags
if (!empty($tags)) {
    foreach ($tags as $i => $tag) {
        $sql .= " AND listeTag LIKE :tag$i";
        $params[":tag$i"] = "%" . $tag . "%";
    }
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($result);